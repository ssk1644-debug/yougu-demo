/**
 * 福祉用具デモ商品管理システム  GAS バックエンド（v7：共通商品マスター）
 *  v7 で「共通商品マスター」シートを追加。申請システムと共有する商品データ（下の 共通商品マスター の説明を参照）。
 *  貼り替えたら 関数 setup を1回実行 → デプロイを管理 → 既存のデプロイを編集 →「新しいバージョン」で再デプロイ（URLは変わらない）
 *
 * 【セットアップ手順】
 * 1. Googleスプレッドシートを新規作成 → 拡張機能 → Apps Script に、このコードを貼り付け
 * 2. プロジェクトの設定 → スクリプトプロパティ に以下を登録
 *      OFFICE_WEBHOOK : 事務用Googleチャットスペースの Webhook URL
 *      SALES_WEBHOOK  : (任意) 営業全員のスペースの Webhook URL。担当者個別のURLが無い人はここに送る
 *      OFFICE_MAIL    : 事務のメールアドレス（複数はカンマ区切り）。※個人のGmailでチャットのWebhookが作れない場合は、こちらのメール通知を使う
 *      API_TOKEN      : 合言葉。お客様名が入るので必ず設定（画面の ⚙ 設定に同じ文字列を入れる）
 * 3. 関数 setup を1回実行（シート作成・写真フォルダ作成）→ 権限を承認（Googleドライブへのアクセスも許可）
 * 4. 関数 setupTrigger を1回実行（毎朝8時に期限チェック）
 * 5. デプロイ → 新しいデプロイ → 種類「ウェブアプリ」
 *      実行ユーザー: 自分 / アクセス: 全員 → 発行されたURLを画面の ⚙ 設定に貼る
 * 6. 「担当者」シートに 担当者名 と、通知を受けたいメールアドレス（D列）を入れる（アプリの「＋名前を追加」でも登録できる）。
 *    ※チャットを使える契約（Google Workspace）の場合のみ、個別スペースへ送りたい人は Webhook URL、
 *      共有スペースで @メンション したい人は ChatユーザーID も入れる（どちらも空欄でも動く）
 *
 * 【通知のルール】
 *  貸出時に「返却予定日」は貸出日の7日後が自動で入る（画面で変更可）。
 *  毎朝8時に、返却予定日の「前日」から担当営業へ、期限を「過ぎたら」事務にもGoogleチャットで連絡。
 *  返却されるまで、超過した日は毎朝くり返し連絡する。
 *  ※「配達担当（実際に運んだ人）」は担当営業と別に記録できるが、通知は担当営業のみに送る。
 *  ※画面の「まとめて持出・返却」からは lendBulk／returnBulk を使い、複数商品を1回の操作で処理する。
 */

const GAS_VER = 8;   // サーバー側の版。画面（index.html）の NEED_GAS 以上でないと、画面が「GASが古い」と警告する
const SHEET_ITEMS = 'デモ商品';
const SHEET_HIST  = '履歴';
const SHEET_STAFF = '担当者';
const SHEET_ARR   = '入荷履歴';
const HEADERS = ['ID','機種','号機','型番','カテゴリ','メーカー','状態','貸出先','貸出日','返却期限','担当者','配達担当','予約者','予約日','場所','メモ','写真','更新日時','区分','仕入単価','色','サイズ','肘'];
const ARR_HEADERS = ['ID','日付','機種','型番','メーカー','数量','仕入先','単価','担当者','メモ','更新日時','JAN'];
const SHEET_MST = '商品マスタ';
const MST_HEADERS = ['キー','データ','更新日時'];
const TEXT_COLS = ['ID','型番','貸出日','返却期限','予約日','メモ','写真'];   // 自動変換されないよう文字列固定
const DEFAULT_LEND_DAYS = 7;    // 返却予定日の自動値（貸出日＋7日）
const NOTICE_DAYS_BEFORE = 1;   // 担当営業へは返却予定日の「前日」から連絡（1=前日／0=当日）
const OFFICE_AFTER_DUE = true;  // 事務へは「期限を過ぎてから」連絡（false=事務へは連絡しない）
const STAFF_HEADERS = ['担当者名','Webhook URL(任意)','ChatユーザーID(任意)','メールアドレス(通知先)'];

/* ---------- Web API ---------- */
function doGet(e)  { return respond_(handle_(e.parameter || {})); }
function doPost(e) {
  let p = {};
  try { p = JSON.parse(e.postData.contents); } catch (err) {}
  return respond_(handle_(p));
}
function respond_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
function handle_(p) {
  const token = PropertiesService.getScriptProperties().getProperty('API_TOKEN');
  if (token && p.token !== token) return { ok: false, error: '認証エラー（合言葉が違います）' };
  try {
    switch (p.action) {
      case 'list':   return { ok: true, items: list_(), staff: staffNames_(), ver: GAS_VER };
      case 'staffAdd':   return withLock_(() => staffAdd_(p.name, p.user, p.email));
      case 'save':   return withLock_(() => save_(p.item, p.user));
      case 'lend':       return withLock_(() => lend_(p));
      case 'return':     return withLock_(() => return_(p.id, p.user));
      case 'lendBulk':   return withLock_(() => lendBulk_(p));
      case 'returnBulk': return withLock_(() => returnBulk_(p));
      case 'delete':     return withLock_(() => delete_(p.id, p.user));
      case 'photo':      return photo_(p);
      case 'import':     return withLock_(() => import_(p.items, p.user));
      case 'arrivalList':   return { ok: true, arrivals: arrList_() };
      case 'arrivalSave':    return withLock_(() => arrSave_(p.item, p.user));
      case 'arrivalDelete':  return withLock_(() => arrDelete_(p.id, p.user));
      case 'masterList':     return { ok: true, master: mstList_() };
      case 'masterSave':     return withLock_(() => mstSave_(p.entries, p.user, p.quiet));
      default:       return { ok: false, error: 'unknown action' };
    }
  } catch (err) { return { ok: false, error: String(err) }; }
}
function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

/* ---------- シート操作 ---------- */
function now_() { return Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd HH:mm'); }
function today_() { return Utilities.formatDate(new Date(), 'Asia/Tokyo', 'yyyy-MM-dd'); }
function addDays_(ymd, n) {
  const d = new Date(ymd + 'T00:00:00+09:00');
  d.setDate(d.getDate() + n);
  return Utilities.formatDate(d, 'Asia/Tokyo', 'yyyy-MM-dd');
}
function sheet_(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold').setBackground('#e8f0fe');
    sh.setFrozenRows(1);
    if (name === SHEET_ITEMS) TEXT_COLS.forEach(h => sh.getRange(1, HEADERS.indexOf(h) + 1, sh.getMaxRows(), 1).setNumberFormat('@'));
  } else if (sh.getLastColumn() < headers.length) {
    // 後から増えた列（色・仕入単価・JAN など）の見出しを自動で足す。既存データはそのまま。
    const need = headers.length;
    if (sh.getMaxColumns() < need) sh.insertColumnsAfter(sh.getMaxColumns(), need - sh.getMaxColumns());
    sh.getRange(1, 1, 1, need).setValues([headers]).setFontWeight('bold').setBackground('#e8f0fe');
  }
  return sh;
}
function fmtDate_(v) {
  if (!v) return '';
  if (v instanceof Date) return Utilities.formatDate(v, 'Asia/Tokyo', 'yyyy-MM-dd');
  return String(v).slice(0, 10);
}
function list_() {
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  const last = sh.getLastRow();
  if (last < 2) return [];
  const rows = sh.getRange(2, 1, last - 1, HEADERS.length).getValues();
  return rows.filter(r => r[0] !== '').map(r => {
    const o = {};
    HEADERS.forEach((h, i) => {
      const v = r[i];
      o[h] = (h === '貸出日' || h === '返却期限' || h === '予約日') ? fmtDate_(v)
           : (h === '更新日時' && v instanceof Date) ? Utilities.formatDate(v, 'Asia/Tokyo', 'yyyy-MM-dd HH:mm')
           : (v instanceof Date) ? fmtDate_(v) : v;
    });
    return o;
  });
}
function findRow_(sh, id) {
  const last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues().map(r => String(r[0]));
  const i = ids.indexOf(String(id));
  return i < 0 ? -1 : i + 2;
}
function rowOf_(item) { return HEADERS.map(h => item[h] === undefined ? '' : item[h]); }
function writeItem_(sh, item) {
  item['更新日時'] = now_();
  const r = findRow_(sh, item['ID']);
  if (r < 0) sh.appendRow(rowOf_(item)); else sh.getRange(r, 1, 1, HEADERS.length).setValues([rowOf_(item)]);
}
function dispName_(it) {
  const circ = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳';
  const n = Number(it['号機']);
  return it['機種'] + (n ? ' ' + (circ[n - 1] || ('#' + n)) : '');
}
function log_(id, name, action, detail, user) {
  const h = sheet_(SHEET_HIST, ['日時','ID','商品名','操作','内容','操作者']);
  h.appendRow([now_(), id, name, action, detail || '', user || '']);
}
function memoAdd_(item, text, user) {
  if (!text) return;
  let arr = [];
  try { arr = JSON.parse(item['メモ'] || '[]'); } catch (e) {}
  arr.push({ d: today_(), t: text, w: user || '' });
  item['メモ'] = JSON.stringify(arr);
}

function save_(item, user) {
  if (!item || !item['ID']) return { ok: false, error: 'IDが空です' };
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  const isNew = findRow_(sh, item['ID']) < 0;
  // 他の端末が先に更新していたら上書きしない（古い画面からの保存で、貸出などが消えるのを防ぐ）
  if (!isNew && item['__base']) {
    const cur = list_().find(x => String(x['ID']) === String(item['ID']));
    if (cur && String(cur['更新日時'] || '') !== String(item['__base'])) {
      return { ok: false, error: '他の端末で先に更新されています。画面を最新にしたので、もう一度やり直してください', items: list_() };
    }
  }
  delete item['__base'];
  writeItem_(sh, item);
  log_(item['ID'], dispName_(item), isNew ? '登録' : '更新', item['状態'], user);
  return { ok: true, items: list_() };
}
function lend_(p) {
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  if (findRow_(sh, p.id) < 0) return { ok: false, error: '該当なし' };
  const cur = list_().find(x => String(x['ID']) === String(p.id));
  // すでに貸出中なら二重貸出を止める（他の端末で先に貸し出された場合）。貸出先の修正（p.fix）だけは通す
  if (cur['状態'] === '貸出中' && !p.fix) {
    return { ok: false, error: '他の端末で先に貸出中になっています（貸出先：' + (cur['貸出先'] || '未入力') + '）。画面を最新にしてから確認してください', items: list_() };
  }
  const from = p.from || today_();
  cur['状態'] = '貸出中'; cur['貸出先'] = p.dest; cur['貸出日'] = from;
  cur['返却期限'] = p.due || addDays_(from, DEFAULT_LEND_DAYS);   // 未指定なら貸出日の7日後
  cur['担当者'] = p.staff; cur['配達担当'] = p.driver || ''; cur['予約者'] = ''; cur['予約日'] = '';
  memoAdd_(cur, p.note, p.user || p.staff);
  writeItem_(sh, cur);
  log_(p.id, dispName_(cur), '貸出', p.dest + ' / 返却予定' + cur['返却期限'] + (p.driver ? ' / 配達:' + p.driver : ''), p.user || p.staff);
  return { ok: true, items: list_() };
}
function return_(id, user) {
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  if (findRow_(sh, id) < 0) return { ok: false, error: '該当なし' };
  const cur = list_().find(x => String(x['ID']) === String(id));
  const was = cur['貸出先'];
  cur['状態'] = '在庫'; cur['貸出先'] = ''; cur['貸出日'] = ''; cur['返却期限'] = '';
  writeItem_(sh, cur);
  log_(id, dispName_(cur), '返却', was, user || cur['担当者']);
  return { ok: true, items: list_() };
}
function lendBulk_(p) {
  const ids = p.ids || [];
  if (!ids.length) return { ok: false, error: '対象がありません' };
  const results = ids.map(id => { const r = lend_(Object.assign({}, p, { id: id })); return { id: id, ok: r.ok, error: r.error }; });
  return { ok: true, items: list_(), results: results };
}
function returnBulk_(p) {
  const ids = p.ids || [];
  if (!ids.length) return { ok: false, error: '対象がありません' };
  const results = ids.map(id => { const r = return_(id, p.user); return { id: id, ok: r.ok, error: r.error }; });
  return { ok: true, items: list_(), results: results };
}
function delete_(id, user) {
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  const r = findRow_(sh, id);
  if (r < 0) return { ok: false, error: '該当なし' };
  const name = sh.getRange(r, 2).getValue();
  sh.deleteRow(r);
  log_(id, name, '削除', '', user);
  return { ok: true, items: list_() };
}
function import_(items, user) {
  if (!items || !items.length) return { ok: false, error: 'データがありません' };
  const sh = sheet_(SHEET_ITEMS, HEADERS);
  const last = sh.getLastRow();
  const map = {};
  if (last >= 2) sh.getRange(2, 1, last - 1, 1).getValues().forEach((r, i) => map[String(r[0])] = i + 2);
  const fresh = [];
  items.forEach(it => {
    if (!it['ID']) return;
    it['更新日時'] = now_();
    if (map[it['ID']]) sh.getRange(map[it['ID']], 1, 1, HEADERS.length).setValues([rowOf_(it)]);
    else { fresh.push(rowOf_(it)); map[it['ID']] = -1; }
  });
  if (fresh.length) sh.getRange(sh.getLastRow() + 1, 1, fresh.length, HEADERS.length).setValues(fresh);
  log_('-', '-', '一括取込', items.length + '件', user);
  return { ok: true, items: list_() };
}

/* ---------- 入荷履歴（新品入荷の記録） ---------- */
function arrList_() {
  const sh = sheet_(SHEET_ARR, ARR_HEADERS);
  const last = sh.getLastRow();
  if (last < 2) return [];
  const rows = sh.getRange(2, 1, last - 1, ARR_HEADERS.length).getValues();
  return rows.filter(r => r[0] !== '').map(r => {
    const o = {};
    ARR_HEADERS.forEach((h, i) => {
      const v = r[i];
      o[h] = (h === '日付' && v instanceof Date) ? fmtDate_(v)
           : (h === '更新日時' && v instanceof Date) ? Utilities.formatDate(v, 'Asia/Tokyo', 'yyyy-MM-dd HH:mm')
           : v;
    });
    return o;
  });
}
function arrFindRow_(sh, id) {
  const last = sh.getLastRow();
  if (last < 2) return -1;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues().map(r => String(r[0]));
  const i = ids.indexOf(String(id));
  return i < 0 ? -1 : i + 2;
}
function arrSave_(item, user) {
  if (!item || !item['ID']) return { ok: false, error: 'IDが空です' };
  const sh = sheet_(SHEET_ARR, ARR_HEADERS);
  item['更新日時'] = now_();
  const r = arrFindRow_(sh, item['ID']);
  const row = ARR_HEADERS.map(h => item[h] === undefined ? '' : item[h]);
  if (r < 0) sh.appendRow(row); else sh.getRange(r, 1, 1, ARR_HEADERS.length).setValues([row]);
  log_(item['ID'], item['機種'], '入荷', `数量:${item['数量']||''} / 仕入先:${item['仕入先']||''}${item['単価']?' / 単価:'+item['単価']+'円':''}`, user);
  return { ok: true, arrivals: arrList_() };
}
function arrDelete_(id, user) {
  const sh = sheet_(SHEET_ARR, ARR_HEADERS);
  const r = arrFindRow_(sh, id);
  if (r < 0) return { ok: false, error: '該当なし' };
  sh.deleteRow(r);
  log_(id, '-', '入荷取消', '', user);
  return { ok: true, arrivals: arrList_() };
}

/* ---------- 商品マスタ（発注実績から作った商品データ＋入荷で覚えた商品） ---------- */
function mstSheet_() {
  const sh = sheet_(SHEET_MST, MST_HEADERS);
  sh.getRange(1, 1, sh.getMaxRows(), 1).setNumberFormat('@');   // JANの先頭の0が消えないよう文字列固定
  return sh;
}
/* ---------- 共通商品マスター（このアプリと 福祉用具販売申請システム で共有する商品データ） ----------
 * シート「共通商品マスター」：1行＝1商品。人が見て直接直せる表にしてある（種目・TAISコード・上代などはシートで直してよい）。
 *   種目が空欄の商品は、画面側がカテゴリと商品名から自動で判定する。特定福祉用具でないと決めた商品は「対象外」と入れる。
 * 申請システムなど他のアプリからは、このウェブアプリに  {action:'masterList', token:合言葉}  を送ると全件が返る。
 *   返る項目：key, jan, name, model, maker, shumoku(種目), tais(TAISコード), retail(上代・税抜), cost(仕入単価・税抜),
 *             sup(仕入先), webcd(卸の商品コード：ウェルファン品番／介援隊WEBCD), cat(在庫のカテゴリ), field, photo, min(発注点), last, hist
 * 旧シート「商品マスタ」（JSON形式）は、初回に自動でこちらへ移し替える（旧シートはそのまま残す＝控え）。
 */
const SHEET_CMST = '共通商品マスター';
const CMST_COLS = [
  ['key', 'キー'],
  ['jan', 'JAN'],
  ['name', '商品名'],
  ['model', '型番'],
  ['maker', 'メーカー'],
  ['shumoku', '種目'],
  ['tais', 'TAISコード'],
  ['retail', '上代（税抜）'],
  ['cost', '仕入単価（税抜）'],
  ['sup', '仕入先'],
  ['webcd', '卸の商品コード'],
  ['cat', '在庫カテゴリ'],
  ['field', '分野'],
  ['photo', '写真URL'],
  ['min', '発注点'],
  ['last', '最終仕入日'],
  ['hist', '仕入単価の履歴'],
  ['wcost', 'ウェルファン単価（税抜）'],
  ['wdate', 'ウェルファン仕入日'],
  ['kcost', '介援隊単価（税抜）'],
  ['kunit', '介援隊の単位'],
  ['kdate', '介援隊仕入日'],
  ['khist', '介援隊単価の履歴']
];
const CMST_HEADERS = CMST_COLS.map(c => c[1]).concat(['更新日時','更新者']);
const CMST_NUM = ['retail','cost','min','wcost','kcost'];
const CMST_JSON = ['hist','khist'];
function cmstSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_CMST);
  if (!sh) {
    sh = sheet_(SHEET_CMST, CMST_HEADERS);
    ['key','jan','model','tais','webcd','last'].forEach(k => {
      const c = CMST_COLS.findIndex(x => x[0] === k) + 1;
      sh.getRange(1, c, sh.getMaxRows(), 1).setNumberFormat('@');   // 先頭の0や長い数字が崩れないよう文字列固定
    });
    sh.setColumnWidth(3, 320);
  } else {
    cmstMigrate_(sh);
  }
  return sh;
}
/* 列が増えたとき：見出しの名前で読み直して、新しい並びで書き直す（データは消えない） */
function cmstMigrate_(sh) {
  const W = sh.getLastColumn();
  if (W < 1) return;
  const head = sh.getRange(1, 1, 1, W).getValues()[0].map(String);
  if (head.length === CMST_HEADERS.length && head.every((h, i) => h === CMST_HEADERS[i])) return;
  const v = sh.getDataRange().getValues();
  const idx = CMST_HEADERS.map(h => head.indexOf(h));
  const rows = v.slice(1).map(r => idx.map(j => j >= 0 ? r[j] : ''));
  sh.clearContents();
  ['wdate','kdate','kunit'].forEach(k => {
    const c = CMST_COLS.findIndex(x => x[0] === k) + 1;
    sh.getRange(1, c, sh.getMaxRows(), 1).setNumberFormat('@');
  });
  if (sh.getMaxColumns() < CMST_HEADERS.length) sh.insertColumnsAfter(sh.getMaxColumns(), CMST_HEADERS.length - sh.getMaxColumns());
  sh.getRange(1, 1, 1, CMST_HEADERS.length).setValues([CMST_HEADERS]).setFontWeight('bold');
  if (rows.length) sh.getRange(2, 1, rows.length, CMST_HEADERS.length).setValues(rows);
}
function cmstRead_(sh) {
  const v = sh.getDataRange().getValues(), out = [];
  for (let i = 1; i < v.length; i++) {
    if (v[i][0] === '' || v[i][0] == null) continue;
    const o = {};
    CMST_COLS.forEach(([k], j) => {
      let x = v[i][j];
      if (x instanceof Date) x = Utilities.formatDate(x, 'Asia/Tokyo', 'yyyy-MM-dd');
      if (CMST_JSON.indexOf(k) >= 0) { try { x = x ? JSON.parse(x) : []; } catch (e) { x = []; } }
      else if (CMST_NUM.indexOf(k) >= 0) x = (x === '' || x == null) ? null : Number(x);
      else x = (x == null) ? '' : String(x);
      o[k] = x;
    });
    if (o.min == null) delete o.min;
    ['wcost','kcost'].forEach(k => { if (o[k] == null) delete o[k]; });
    ['wdate','kdate','kunit'].forEach(k => { if (o[k] === '') delete o[k]; });
    if (!o.khist || !o.khist.length) delete o.khist;
    out.push(o);
  }
  return out;
}
function mstList_() {
  const sh = cmstSheet_();
  if (sh.getLastRow() < 2) {   // 初回：旧「商品マスタ」(JSON) から移し替える
    const old = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_MST);
    if (old && old.getLastRow() > 1) {
      const v = old.getDataRange().getValues(), ents = [];
      for (let i = 1; i < v.length; i++) { try { const o = JSON.parse(v[i][1]); if (o && o.key) ents.push(o); } catch (e) {} }
      if (ents.length) cmstUpsert_(sh, ents, '移し替え');
    }
  }
  return cmstRead_(sh);
}
function cmstUpsert_(sh, entries, user) {
  const v = sh.getDataRange().getValues(), pos = {};
  for (let i = 1; i < v.length; i++) pos[String(v[i][0])] = i;
  const stamp = now_(), add = [], W = CMST_HEADERS.length;
  entries.forEach(e => {
    if (!e || !e.key) return;
    const key = String(e.key), base = (pos[key] != null) ? v[pos[key]].slice(0, W) : new Array(W).fill('');
    while (base.length < W) base.push('');
    CMST_COLS.forEach(([k], j) => {
      if (!(k in e) || e[k] === undefined) return;   // 送られてこなかった項目は、シートの値（人が直した種目など）をそのまま残す
      let x = e[k];
      if (CMST_JSON.indexOf(k) >= 0) x = JSON.stringify(x || []);
      else if (x == null) x = '';
      base[j] = x;
    });
    base[0] = key; base[W - 2] = stamp; base[W - 1] = user || '';
    if (pos[key] != null) { v[pos[key]] = base; sh.getRange(pos[key] + 1, 1, 1, W).setValues([base]); }
    else { add.push(base); pos[key] = -1; }
  });
  if (add.length) sh.getRange(sh.getLastRow() + 1, 1, add.length, W).setValues(add);
}
function mstSave_(entries, user, quiet) {
  if (!entries || !entries.length) return quiet ? { ok: true, n: 0 } : { ok: true, master: mstList_() };
  const sh = cmstSheet_();
  if (sh.getLastRow() < 2) mstList_();   // 移し替えが済んでいなければ先に行う
  cmstUpsert_(sh, entries, user);
  log_('', '共通商品マスター', '更新', entries.length + '件', user);
  return quiet ? { ok: true, n: entries.length } : { ok: true, master: mstList_() };
}

/* ---------- 写真（Googleドライブに保存） ---------- */
function photoFolder_() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('PHOTO_FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const f = DriveApp.createFolder('デモ商品写真');
  props.setProperty('PHOTO_FOLDER_ID', f.getId());
  return f;
}
function photo_(p) {
  if (!p.id || !p.data) return { ok: false, error: '写真データがありません' };
  const blob = Utilities.newBlob(Utilities.base64Decode(p.data), p.mime || 'image/jpeg', p.id + '_' + Date.now() + '.jpg');
  const f = photoFolder_().createFile(blob);
  f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return { ok: true, url: 'https://drive.google.com/thumbnail?id=' + f.getId() + '&sz=w800' };
}

function staffAdd_(name, user, email) {
  name = String(name || '').trim();
  email = String(email || '').trim();
  if (!name) return { ok: false, error: '名前が空です' };
  const sh = sheet_(SHEET_STAFF, STAFF_HEADERS);
  const last = sh.getLastRow();
  const names = last < 2 ? [] : sh.getRange(2, 1, last - 1, 1).getValues().map(r => String(r[0]));
  const idx = names.indexOf(name);
  if (idx < 0) { sh.appendRow([name, '', '', email]); log_('-', '-', '担当者追加', name, user); }
  else if (email) { sh.getRange(idx + 2, 4).setValue(email); log_('-', '-', '担当者メール登録', name, user); }
  return { ok: true, staff: staffNames_() };
}
function staffNames_() {
  const sh = sheet_(SHEET_STAFF, STAFF_HEADERS);
  const last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 1).getValues().map(r => String(r[0])).filter(String);
}

/* ---------- 初期セットアップ ---------- */
function setup() {
  sheet_(SHEET_ITEMS, HEADERS);
  sheet_(SHEET_HIST, ['日時','ID','商品名','操作','内容','操作者']);
  sheet_(SHEET_ARR, ARR_HEADERS);
  mstSheet_();
  cmstSheet_(); mstList_();   // 共通商品マスター（旧「商品マスタ」から自動で移し替え）
  const st = sheet_(SHEET_STAFF, STAFF_HEADERS);
  if (st.getLastRow() < 2) st.appendRow(['山田（例）', '', '']);
  photoFolder_();   // ドライブへのアクセス許可を取るためここで1回作成
}

/* ---------- 返却予定日の連絡（事務＋担当営業へ Googleチャット） ---------- */
function setupTrigger() {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'dailyCheck').forEach(t => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('dailyCheck').timeBased().everyDays(1).atHour(8).inTimezone('Asia/Tokyo').create();
}

function dailyCheck() {
  const today = new Date(today_() + 'T00:00:00+09:00');
  const targets = [];
  list_().forEach(it => {
    if (it['状態'] !== '貸出中' || !it['返却期限']) return;   // 期限未設定(移行データ等)は通知しない
    const diff = Math.round((new Date(it['返却期限'] + 'T00:00:00+09:00') - today) / 86400000);  // 1=明日 / 0=本日 / 負=超過
    const days = it['貸出日'] ? Math.max(0, Math.round((today - new Date(it['貸出日'] + 'T00:00:00+09:00')) / 86400000)) : null;   // 貸出して何日たったか
    if (diff <= NOTICE_DAYS_BEFORE) targets.push({ it, diff, days });
  });
  if (!targets.length) return;

  const line = (t, mention) => {
    const d = t.diff;
    const tag = d < 0 ? `🔴 ${-d}日超過` : d === 0 ? '🟠 本日が返却予定日' : `🟡 明日が返却予定日`;
    const who = mention || t.it['担当者'] || '担当未設定';
    return `${tag}｜${dispName_(t.it)}（${t.it['ID']}）\n　貸出先: ${t.it['貸出先']} ／ 貸出日: ${t.it['貸出日']}${t.days === null ? '' : '（' + t.days + '日経過）'} ／ 返却予定: ${t.it['返却期限']} ／ 担当: ${who}${t.it['配達担当'] ? ' ／ 配達: ' + t.it['配達担当'] : ''}`;
  };
  const props = PropertiesService.getScriptProperties();
  const officeMail = props.getProperty('OFFICE_MAIL');      // 事務のメール（複数はカンマ区切り）
  const overdue = targets.filter(t => t.diff < 0);

  // ① 事務：期限を過ぎたものだけ、まとめて（チャット＋メール）
  const office = props.getProperty('OFFICE_WEBHOOK');
  if (OFFICE_AFTER_DUE && overdue.length) {
    const body = overdue.map(t => line(t)).join('\n\n');
    if (office) postChat_(office, `🔴【デモ商品 返却期限を過ぎています】${overdue.length}件\n\n` + body);
    mail_(officeMail, `【デモ商品】返却期限を過ぎています（${overdue.length}件）`, body);
  }

  // ② 担当営業：前日・当日・超過を、担当ごとに（個別Webhook → 営業スペース → メール の順に届く先を使う。メールは登録があれば必ず送る）
  const sales = props.getProperty('SALES_WEBHOOK');
  const sh = sheet_(SHEET_STAFF, STAFF_HEADERS);
  const last = sh.getLastRow();
  const staffRows = last < 2 ? [] : sh.getRange(2, 1, last - 1, 4).getValues();
  const byStaff = {};
  targets.forEach(t => { const k = t.it['担当者'] || ''; (byStaff[k] = byStaff[k] || []).push(t); });
  const lost = [];   // 連絡先が無くて、誰にも届かなかったもの

  Object.keys(byStaff).forEach(name => {
    const mine = byStaff[name];
    const row = staffRows.find(r => String(r[0]) === name) || [];
    const hook = row[1], uid = row[2], addr = String(row[3] || '').trim();
    let sent = false;
    if (hook) {
      postChat_(hook, `📦【${name}さん 返却のご連絡】${mine.length}件\n\n` + mine.map(t => line(t)).join('\n\n')); sent = true;
    } else if (sales) {
      const m = name ? (uid ? `<users/${uid}>` : name) : '担当未設定';
      postChat_(sales, `📦【${m} 返却のご連絡】${mine.length}件\n\n` + mine.map(t => line(t, m)).join('\n\n')); sent = true;
    }
    if (addr) {
      mail_(addr, `【デモ商品】${name}さん 返却のご連絡（${mine.length}件）`, `${name}さん\n\n` + mine.map(t => line(t)).join('\n\n') + '\n\n※返却したら、アプリで「返却」を押してください。'); sent = true;
    }
    if (!sent) lost.push(...mine);
  });
  // ③ 担当者に連絡先が無い／担当未設定のもの → 事務のメールへ（見落とし防止）
  if (lost.length && officeMail) mail_(officeMail, `【デモ商品】担当者の連絡先が未登録の返却連絡（${lost.length}件）`, '次の商品は担当者の連絡先（メール）が登録されていないため、事務へお送りしています。\n\n' + lost.map(t => line(t)).join('\n\n'));
}

/** メール送信（宛先は「,」区切りで複数可。空なら何もしない） */
function mail_(to, subject, body) {
  to = String(to || '').split(/[,、;\s]+/).filter(s => /@/.test(s)).join(',');
  if (!to) return;
  try { MailApp.sendEmail({ to: to, subject: subject, body: body, name: 'デモ商品管理システム' }); }
  catch (e) { console.error('mail failed: ' + e); }
}

function postChat_(url, text) {
  UrlFetchApp.fetch(url, {
    method: 'post', contentType: 'application/json; charset=UTF-8',
    payload: JSON.stringify({ text: text }), muteHttpExceptions: true
  });
}

/** 疎通テスト（手動実行）：事務・営業スペースとメールにテスト文を送る。初回は「メール送信」の権限の承認が出ます */
function testNotify() {
  const props = PropertiesService.getScriptProperties();
  ['OFFICE_WEBHOOK', 'SALES_WEBHOOK'].forEach(k => {
    const u = props.getProperty(k);
    if (u) postChat_(u, '✅ デモ商品管理システムからのテスト通知です（' + k + '）');
  });
  mail_(props.getProperty('OFFICE_MAIL'), '【デモ商品】テスト通知（事務）', '✅ デモ商品管理システムからのテストメールです。このメールが届けば、事務への通知は設定できています。');
  const sh = sheet_(SHEET_STAFF, STAFF_HEADERS), last = sh.getLastRow();
  if (last >= 2) sh.getRange(2, 1, last - 1, 4).getValues().forEach(r => { if (r[3]) mail_(r[3], '【デモ商品】テスト通知', `✅ ${r[0]}さん宛てのテストメールです。このメールが届けば、${r[0]}さんへの通知は設定できています。`); });
}
